# 🚀 Guide de déploiement Smile AI
### Pour débutants — Aucune connaissance en programmation nécessaire !

---

## ✅ ÉTAPE 1 : Créer le compte GitHub (5 minutes)

GitHub est l'endroit où on va stocker ton code.

1. Va sur **github.com**
2. Clique sur **"Sign up"**
3. Crée ton compte (email + mot de passe)
4. Confirme ton email

---

## ✅ ÉTAPE 2 : Mettre ton code sur GitHub (5 minutes)

1. Une fois connecté sur GitHub, clique sur **"New repository"** (bouton vert)
2. Nom du projet : `smile-ai`
3. Laisse tout par défaut et clique **"Create repository"**
4. Clique sur **"uploading an existing file"**
5. Glisse-dépose le dossier **`smile-ai`** (avec ses fichiers)
6. Clique **"Commit changes"** (bouton vert en bas)

✅ Ton code est maintenant en ligne sur GitHub !

---

## ✅ ÉTAPE 3 : Déployer sur Vercel (3 minutes)

Vercel va rendre ton site accessible à tout le monde, gratuitement.

1. Va sur **vercel.com**
2. Clique **"Sign Up"** → choisir **"Continue with GitHub"**
3. Autorise Vercel à accéder à GitHub
4. Clique **"Add New Project"**
5. Sélectionne ton repo **`smile-ai`**
6. Clique **"Deploy"**

⏳ Attends 1-2 minutes...

🎉 **Ton site est en ligne !** Vercel te donne une URL comme :
`https://smile-ai-ton-nom.vercel.app`

---

## ✅ ÉTAPE 4 : Configurer Google OAuth (15 minutes)

C'est pour que les utilisateurs puissent se connecter avec leur compte Gmail.

### 4.1 — Créer le projet Google

1. Va sur **console.cloud.google.com**
2. Connecte-toi avec TON compte Google
3. Clique sur le menu déroulant en haut → **"Nouveau projet"**
4. Nom : `Smile AI` → Clique **"Créer"**

### 4.2 — Configurer l'écran de consentement

1. Dans le menu gauche → **"APIs et services"** → **"Écran de consentement OAuth"**
2. Choisis **"Externe"** → Clique **"Créer"**
3. Remplis :
   - **Nom de l'application** : `Smile AI`
   - **Email d'assistance utilisateur** : ton email
   - **Email du développeur** : ton email
4. Clique **"Enregistrer et continuer"** (3 fois jusqu'à la fin)

### 4.3 — Créer les identifiants OAuth

1. Dans le menu gauche → **"Identifiants"**
2. Clique **"+ Créer des identifiants"** → **"ID client OAuth"**
3. Type d'application : **"Application Web"**
4. Nom : `Smile AI Web`
5. Dans **"Origines JavaScript autorisées"**, ajoute :
   - `https://smile-ai-ton-nom.vercel.app` *(remplace par ton URL Vercel)*
   - `http://localhost:3000` *(pour les tests)*
6. Clique **"Créer"**

📋 **COPIE ton "ID client"** — ça ressemble à :
`123456789-abcdef.apps.googleusercontent.com`

### 4.4 — Coller l'ID dans le code

1. Ouvre le fichier `public/index.html`
2. Cherche cette ligne (vers le milieu du fichier) :
   ```
   data-client_id="VOTRE_GOOGLE_CLIENT_ID"
   ```
3. Remplace `VOTRE_GOOGLE_CLIENT_ID` par ton vrai ID, exemple :
   ```
   data-client_id="123456789-abcdef.apps.googleusercontent.com"
   ```
4. Sauvegarde le fichier
5. Va sur GitHub → remplace le fichier → **"Commit changes"**

Vercel redéploiera automatiquement en 1-2 minutes ! ✅

---

## ✅ ÉTAPE 5 : Configurer Stripe pour les paiements (optionnel)

Pour recevoir des paiements Premium (9€/mois).

1. Va sur **stripe.com** → Crée un compte
2. Dans le dashboard → **"Produits"** → **"Ajouter un produit"**
   - Nom : `Smile AI Premium`
   - Prix : `9,00 €` / mois (récurrent)
3. Copie le **lien de paiement** généré
4. Dans `index.html`, remplace la fonction `processPurchase()` :
   ```javascript
   function processPurchase() {
     window.open('TON_LIEN_STRIPE_ICI', '_blank');
   }
   ```

---

## 🌐 Ton domaine personnalisé (optionnel)

Pour avoir `www.smileai.fr` au lieu de `smile-ai.vercel.app` :

1. Achète un domaine sur **OVH** ou **Namecheap** (~10€/an)
2. Dans Vercel → ton projet → **"Domains"**
3. Ajoute ton domaine et suis les instructions

---

## 📊 Résumé des coûts

| Service | Coût |
|---------|------|
| GitHub | 🆓 Gratuit |
| Vercel | 🆓 Gratuit (jusqu'à 100GB/mois) |
| Google OAuth | 🆓 Gratuit |
| Stripe | 🆓 Gratuit + 1,4% par transaction |
| Domaine .fr | ~10€/an |

**Total pour lancer : 0€** (ou 10€ avec domaine personnalisé)

---

## 🆘 Besoin d'aide ?

Si tu bloques sur une étape, reviens me voir avec l'étape où tu es bloqué(e) et je t'aide pas à pas ! 😊
